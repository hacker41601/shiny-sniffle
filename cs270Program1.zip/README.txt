Author: Monynich Kiem
Section: 002
Date: Feb. 5, 2020

Contents:
kstring.c (This file contains the functions I wrote and implemented)
kstring.h (This file is the header file that is unmodified and is the basis for my kstring.c file)
test-fulll.o (This file runs all 26 test cases to test whether or not the functions I wrote in kstring.c are successful)
README.txt (The current file you are reading)
script.txt (This file shows the process of building the program)

Running:
I first put make clean in the command line
I run the makefile that was provided and unmodified by typing make in the command line
I test the cases after running make by typing ./test-full in the command line

Implementation Notes:
The use of the strdup() function was met with some difficulty using due to it not includine a line to define the type of C language it was using in Linux. This was solved with the assistance of Dr. Moore and using the cppreference pages forstrdup()

Limitations:
There was some segmentations faults whenever I was running and editing the code for kstrextend and kstrcat in which my extend function was having difficulty on how to populate the new longer array and a similar problem was met for kstrcat when there was not enough room to populate the array.

References:
I did not recieve any help from my peers in the final version of my code.
I went to office hours and received assistance from Dr. Moore as he explained the functions within in the C library to me and helped me visualize the functions.

These are the sites that was provided and were used in the final products of my own code:
https://en.cppreference.com/w/c/string/byte/strlen
https://en.cppreference.com/w/c/string/byte/memset
https://en.cppreference.com/w/c/memory/realloc
https://en.cppreference.com/w/c/experimental/dynamic/strdup
