#include <stdlib.h>
#include <stdio.h>
#define __STDC_WANT_LIB_EXT2__ 1 
//^this is in order to use strdup() because strdup() is in the C language, but things get tricky when using Linux and string.h alone will not allow strdup() to be used without errors. Dr. Moore helped me figure out why my strdup() wasn't working in his office hours.
#include <string.h>
#include "kstring.h"

char kstrget(kstring str, size_t pos)
{
	if (pos >= str.length)
	{
		abort();
	}
	return str.data[pos]; 
	//^in C, the str.data acts like a pointer to an array and the pos(ition) is what you want to index into the array to return a specific element
}//end of kstrget

void kstrput(kstring str, size_t pos, char ch)
{
	if (pos >= str.length)
	{
		abort();
	}
	str.data[pos] = ch; 
	//^this is similar to kstrget, just in reverse. Now the indexed position is equal to the char variable ch
}//end of kstrput

size_t kstrlen(kstring str)
{
	return str.length;
}//end of kstrlen

kstring kstralloc(size_t nbytes)
{
	kstring result = { malloc(nbytes), nbytes }; 
	//^inside the curly brace means the result is equal to reallocating the nbytes while also setting it equal to the number of nbytes in the array which is used later on in result.data
	if (result.data == NULL && nbytes != 0)
	{
		printf("Error allocating memory\n");
		abort();
	}
	//memset is implements by memset(pointer, char, size)
	memset( result.data, '\0', nbytes);
	return result;
}//end of kstralloc

kstring kstrfrom(const char *cstr)
{
	kstring result = { NULL, 0 };
	result.data = strdup(cstr); 
	//the strdup() function both using malloc and memcpy all in one
	if ( result.data == NULL )
	{
		printf("Error allocating memory\n");
		abort();
	}
	result.length = strlen(cstr)+1;
	return result;
}//end of kstrfrom

void kstrfree(kstring str)
{
	free(str.data);
}//end of kstrfree

void kstrextend(kstring *strp, size_t nbytes)
{
	//if there are more nbytes being asked for the array should extends and be filled with nullbytes
	//realloc can only extend it but not populate with null bytes
	//if the length is already nbytes or longer it does nothing! extend function does only that, so reducing it is not a possiblity
	if (strp->length >= nbytes)
	{
		return;
	}		
	if (nbytes > strp->length)
	{
		if( (strp->data = realloc(strp->data, nbytes)))
		{
			memset(&(strp->data)[strp->length], '\0', nbytes-(strp->length));
		}
		//the nbytes-the original length is what determines when to fill in the null bytes - which is AFTER the original amount of characters in the string
		strp->length = nbytes;
	}
	else
	{
		printf("Error allocating memory\n");
		abort();
	}
}//end of kstrextend

void kstrcat(kstring *destp, kstring src)
{
	//destp is destination pointer
	//src is the source
	int destpLen = destp->length;
	int srcLen = src.length;
	kstrextend(destp, srcLen + destpLen); //needs to be extended by adding the source and destination or else there will be a segmentation fault
	int i = 0;
	while(src.data[i] != '\0')
	{
        	destp->data[i+destpLen] = src.data[i];
		//the array in destp is the length of the destination and is impleted with the src (source) data as it's being iterated in the while loop
        	i++;
    	}
	destp->data[i+destpLen] = '\0';
}//end of kstrcat
